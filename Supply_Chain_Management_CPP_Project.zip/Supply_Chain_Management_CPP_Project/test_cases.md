# Test Cases (15)

Run each test from a clean folder unless the test requires existing data. Record actual result and Pass/Fail during your own testing.

| No. | Test | Input / Precondition | Expected result |
|---:|---|---|---|
| 1 | Add valid product | ID 101, name `Keyboard`, price 500, stock 10, supplier 0 | Product is saved and success message appears |
| 2 | Reject duplicate product ID | Add product ID 101 again | Duplicate ID rejected |
| 3 | Reject invalid product ID | Product ID 0 or negative | Product is rejected |
| 4 | List products | At least one product exists | Product details and stock are displayed |
| 5 | Search existing product | Search ID 101 | Correct product is displayed |
| 6 | Search missing product | Search ID 9999 | `Product not found` message |
| 7 | Update product name | Existing product ID 101, change name | New name is displayed and persists |
| 8 | Update product price | Existing product ID 101, enter price 650 | New price is displayed and persists |
| 9 | Delete product with no order history | Existing product not used in an order | Product is removed |
| 10 | Replenish stock | Product has stock 10; add 5 | Stock becomes 15 |
| 11 | Add customer | Customer ID 201, name and contact | Customer is saved |
| 12 | Add supplier | Supplier ID 301, contact person, company | Supplier is saved and listed |
| 13 | Place valid order | Customer 201, product 101 with stock 15, quantity 2 | Order created, total is price × 2, stock becomes 13 |
| 14 | Reject excessive order | Request quantity greater than available stock | Order is rejected; stock remains unchanged |
| 15 | Persistence after restart | Add records, exit, restart, list products/customers/orders | Saved records are loaded from files |

**Execution record template:** Actual Result: __________  |  Status: PASS / FAIL  |  Date: __________
