# Supply Chain Management System (C++17)

## Features
- Product add/list/search/update/delete and stock replenishment
- Customer management (add/list/search/delete)
- Supplier management (add/list)
- Place orders and calculate totals; stock is reduced only for valid orders
- Order history
- File persistence in `products.txt`, `customers.txt`, `suppliers.txt`, and `orders.txt`
- Six classes: `Person`, `Customer`, `Supplier`, `Product`, `Order`, `SupplyChainSystem`
- Constructors/destructors, inheritance, runtime polymorphism, and dynamic memory with `std::unique_ptr`

## Compile and run
### Windows (MinGW g++)
```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o SupplyChain.exe
SupplyChain.exe
```
### Linux / macOS
```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o SupplyChain
./SupplyChain
```

Keep the executable and all four `.txt` data files in the same working directory. The program creates data files when it saves data. Data is loaded at startup and saved after changes and on exit.

## OOP requirements
1. **Minimum 5 classes:** Person, Customer, Supplier, Product, Order, SupplyChainSystem.
2. **Constructors + destructors:** Constructors are present in all model classes; `Person` has a virtual destructor and derived classes override it.
3. **Inheritance + polymorphism:** Customer and Supplier inherit from abstract Person and override `role()`, `display()`, and `save()` where applicable.
4. **Dynamic memory:** `std::make_unique` and `std::unique_ptr` allocate and safely release objects.
5. **File persistence:** Data is loaded from and saved to text files.
6. **CRUD:** Product has add/search/update/delete/list; stock can be replenished. Customer management supports add/search/list/delete; customer update is marked unavailable in this teaching version.
7. **Main transaction:** Place order validates customer/product/quantity/stock, calculates total, reduces stock, and records order.
8. **Use case diagram:** See `diagrams.md`.
9. **Class diagram:** See `diagrams.md`.
10. **Two sequence diagrams:** See `diagrams.md`.
11. **15 test cases:** See `test_cases.md`.
12. **Executable + README:** Compile the source using the commands above; include the generated executable when submitting if your instructor requires a platform-specific binary.

## Notes
- IDs must be unique within their own category and greater than zero.
- Use `0` for an unknown supplier ID.
- This is a classroom demonstration, not a production-grade inventory system. Back up the `.txt` files before editing them manually.
